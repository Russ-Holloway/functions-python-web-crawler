import azure.functions as func
import logging
import json
import urllib.request
import urllib.parse
import urllib.error
from datetime import datetime, timezone
from html.parser import HTMLParser
import re
import hashlib
import hmac
import base64
import os
import time

# Cosmos DB Configuration
COSMOS_ENDPOINT = "https://db-btp-uks-prod-doc-crawler-01.documents.azure.com:443/"
COSMOS_DATABASE = "WebCrawlerDB"
COSMOS_CONTAINER = "DocumentMetadata"

# Azure Storage Configuration  
STORAGE_ACCOUNT = "stbtpuksprodcrawler01"
STORAGE_CONTAINER = "documents"

# Website Configuration for Multi-Site Crawling
WEBSITE_CONFIGS = {
    "legislation": {
        "name": "UK Legislation",
        "base_url": "https://www.legislation.gov.uk",
        "crawl_paths": [
            "/ukpga/2025",
            "/uksi/2025", 
            "/new"
        ],
        "priority": 1,
        "enabled": True
    },
    "gov_publications": {
        "name": "GOV.UK Publications", 
        "base_url": "https://www.gov.uk",
        "crawl_paths": [
            "/government/publications",
            "/government/consultations"
        ],
        "priority": 2,
        "enabled": False  # Enable when ready
    },
    "parliament": {
        "name": "UK Parliament",
        "base_url": "https://committees.parliament.uk",
        "crawl_paths": [
            "/committees/documents",
            "/work/documents"
        ],
        "priority": 3,
        "enabled": False  # Enable when ready
    }
}

class EnhancedDocumentLinkParser(HTMLParser):
    """Enhanced HTML parser to find document links with debugging"""
    def __init__(self):
        super().__init__()
        self.document_links = []
        self.all_links = []
        # Extended document extensions including government common formats
        self.document_extensions = {'.pdf', '.doc', '.docx', '.txt', '.xls', '.xlsx', '.xml', '.csv', '.rtf'}
        # Common government document URL patterns
        self.doc_patterns = [
            r'/data/',           # data.gov.uk pattern
            r'/documents?/',     # common docs folder
            r'/publications?/',  # publications folder
            r'/files?/',         # files folder
            r'\.pdf\?',         # PDF with parameters
            r'download',         # download links
        ]
    
    def handle_starttag(self, tag, attrs):
        if tag == 'a':
            for attr_name, attr_value in attrs:
                if attr_name == 'href' and attr_value:
                    self.all_links.append(attr_value)
                    
                    # Check file extensions
                    lower_url = attr_value.lower()
                    if any(lower_url.endswith(ext) for ext in self.document_extensions):
                        self.document_links.append(attr_value)
                    
                    # Check URL patterns that might indicate documents
                    elif any(re.search(pattern, lower_url) for pattern in self.doc_patterns):
                        self.document_links.append(attr_value)

def find_documents_in_html(html_content, base_url):
    """Parse HTML and find document links with enhanced detection"""
    parser = EnhancedDocumentLinkParser()
    try:
        parser.feed(html_content)
        
        # Convert relative URLs to absolute and categorize
        documents = []
        for link in parser.document_links:
            if link.startswith(('http://', 'https://')):
                absolute_url = link
            else:
                absolute_url = urllib.parse.urljoin(base_url, link)
            
            # Determine file type
            lower_link = link.lower()
            if any(lower_link.endswith(ext) for ext in {'.pdf', '.doc', '.docx', '.txt', '.xls', '.xlsx', '.xml', '.csv', '.rtf'}):
                file_ext = lower_link.split('.')[-1]
            else:
                file_ext = 'unknown'
            
            documents.append({
                "url": absolute_url,
                "filename": link.split('/')[-1] if '/' in link else link,
                "extension": file_ext,
                "original_link": link
            })
        
        # Return documents plus debugging info
        return {
            "documents": documents,
            "total_links_found": len(parser.all_links),
            "sample_links": parser.all_links[:10]  # First 10 links for debugging
        }
    except Exception as e:
        logging.error(f'HTML parsing error: {str(e)}')
        return {"documents": [], "total_links_found": 0, "sample_links": []}

def get_managed_identity_token():
    """Get access token using Azure Functions managed identity"""
    try:
        # Try Azure Functions specific environment first
        import os
        msi_endpoint = os.environ.get('IDENTITY_ENDPOINT')
        msi_header = os.environ.get('IDENTITY_HEADER')
        
        if msi_endpoint and msi_header:
            # Azure Functions v2+ managed identity
            params = {
                "api-version": "2019-08-01",
                "resource": "https://storage.azure.com/"
            }
            
            url = f"{msi_endpoint}?{urllib.parse.urlencode(params)}"
            
            req = urllib.request.Request(url)
            req.add_header("X-IDENTITY-HEADER", msi_header)
            
            with urllib.request.urlopen(req, timeout=10) as response:
                token_data = json.loads(response.read().decode())
                return token_data.get("access_token")
        else:
            # Fallback to standard metadata endpoint (VM-style)
            identity_endpoint = "http://169.254.169.254/metadata/identity/oauth2/token"
            
            params = {
                "api-version": "2018-02-01",
                "resource": "https://storage.azure.com/"
            }
            
            url = f"{identity_endpoint}?{urllib.parse.urlencode(params)}"
            
            req = urllib.request.Request(url)
            req.add_header("Metadata", "true")
            
            with urllib.request.urlopen(req, timeout=10) as response:
                token_data = json.loads(response.read().decode())
                return token_data.get("access_token")
            
    except Exception as e:
        logging.error(f'Failed to get managed identity token: {str(e)}')
        logging.error(f'IDENTITY_ENDPOINT: {os.environ.get("IDENTITY_ENDPOINT", "Not set")}')
        logging.error(f'IDENTITY_HEADER: {os.environ.get("IDENTITY_HEADER", "Not set")}')
        return None

def upload_to_blob_storage_real(content, filename, storage_account="stbtpuksprodcrawler01", container="documents"):
    """Upload content to Azure Blob Storage using REST API and managed identity"""
    try:
        # Get access token
        access_token = get_managed_identity_token()
        if not access_token:
            return {
                "success": False,
                "error": "Failed to get access token",
                "message": "Falling back to simulation"
            }
        
        # Construct blob URL
        blob_url = f"https://{storage_account}.blob.core.windows.net/{container}/{filename}"
        
        # Create request
        req = urllib.request.Request(blob_url, data=content, method='PUT')
        req.add_header("Authorization", f"Bearer {access_token}")
        req.add_header("x-ms-blob-type", "BlockBlob")
        req.add_header("x-ms-version", "2021-06-08")
        req.add_header("Content-Length", str(len(content)))
        
        # Determine content type based on file extension
        if filename.lower().endswith('.pdf'):
            req.add_header("Content-Type", "application/pdf")
        elif filename.lower().endswith('.xml'):
            req.add_header("Content-Type", "application/xml")
        elif filename.lower().endswith('.csv'):
            req.add_header("Content-Type", "text/csv")
        else:
            req.add_header("Content-Type", "application/octet-stream")
        
        # Upload to blob storage
        with urllib.request.urlopen(req, timeout=60) as response:
            status_code = response.status
            
        if status_code in [200, 201]:
            logging.info(f'Successfully uploaded {filename} to {blob_url}')
            return {
                "success": True,
                "blob_url": blob_url,
                "size": len(content),
                "message": "Real Azure Storage upload successful",
                "status_code": status_code
            }
        else:
            return {
                "success": False,
                "error": f"Upload failed with status {status_code}",
                "message": "Unexpected response from Azure Storage"
            }
            
    except Exception as e:
        logging.error(f'Real blob upload failed: {str(e)}')
        # Fallback to simulation
        return {
            "success": False,
            "error": str(e),
            "fallback": True,
            "blob_url": f"https://{storage_account}.blob.core.windows.net/{container}/{filename}",
            "size": len(content),
            "message": "Real upload failed, would simulate"
        }

def get_cosmos_access_token():
    """Get access token for Cosmos DB using managed identity"""
    try:
        # Check for Azure Functions environment variables first
        identity_endpoint = os.environ.get('IDENTITY_ENDPOINT')
        identity_header = os.environ.get('IDENTITY_HEADER')
        
        if identity_endpoint and identity_header:
            # Azure Functions managed identity
            token_url = f"{identity_endpoint}?resource=https://cosmos.azure.com&api-version=2019-08-01"
            req = urllib.request.Request(token_url)
            req.add_header('X-IDENTITY-HEADER', identity_header)
        else:
            # Fallback to standard VM metadata endpoint
            token_url = "http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https://cosmos.azure.com"
            req = urllib.request.Request(token_url)
            req.add_header('Metadata', 'true')
        
        with urllib.request.urlopen(req, timeout=10) as response:
            token_data = json.loads(response.read().decode('utf-8'))
            return token_data['access_token']
            
    except Exception as e:
        logging.error(f'Failed to get Cosmos DB access token: {str(e)}')
        return None

def save_document_metadata(document_info, website_source):
    """Save document metadata to Cosmos DB for change tracking"""
    try:
        access_token = get_cosmos_access_token()
        if not access_token:
            logging.warning("No Cosmos access token, skipping metadata save")
            return False
            
        # Create document metadata
        metadata = {
            "id": f"{website_source}_{document_info['filename']}_{document_info['hash']}",
            "partitionKey": website_source,
            "filename": document_info['filename'],
            "url": document_info['url'],
            "hash": document_info['hash'],
            "size": document_info['size'],
            "last_seen": datetime.now(timezone.utc).isoformat(),
            "first_discovered": datetime.now(timezone.utc).isoformat(),
            "website_source": website_source,
            "blob_url": document_info.get('blob_url', ''),
            "status": "active"
        }
        
        # Cosmos DB REST API call
        cosmos_url = f"{COSMOS_ENDPOINT}dbs/{COSMOS_DATABASE}/colls/{COSMOS_CONTAINER}/docs"
        headers = {
            'Authorization': f'Bearer {access_token}',
            'Content-Type': 'application/json',
            'x-ms-version': '2018-12-31',
            'x-ms-documentdb-partitionkey': f'["{website_source}"]'
        }
        
        req = urllib.request.Request(
            cosmos_url,
            data=json.dumps(metadata).encode('utf-8'),
            headers=headers,
            method='POST'
        )
        
        with urllib.request.urlopen(req, timeout=30) as response:
            logging.info(f"Metadata saved for {document_info['filename']} - Status: {response.status}")
            return response.status in [200, 201]
            
    except Exception as e:
        logging.error(f'Failed to save metadata: {str(e)}')
        return False

def get_document_metadata(filename, website_source):
    """Get existing document metadata from Cosmos DB"""
    try:
        access_token = get_cosmos_access_token()
        if not access_token:
            return None
            
        # Query for existing document
        query_url = f"{COSMOS_ENDPOINT}dbs/{COSMOS_DATABASE}/colls/{COSMOS_CONTAINER}/docs"
        query = {
            "query": "SELECT * FROM c WHERE c.filename = @filename AND c.website_source = @website",
            "parameters": [
                {"name": "@filename", "value": filename},
                {"name": "@website", "value": website_source}
            ]
        }
        
        headers = {
            'Authorization': f'Bearer {access_token}',
            'Content-Type': 'application/query+json',
            'x-ms-version': '2018-12-31',
            'x-ms-documentdb-isquery': 'true',
            'x-ms-documentdb-partitionkey': f'["{website_source}"]'
        }
        
        req = urllib.request.Request(
            query_url,
            data=json.dumps(query).encode('utf-8'),
            headers=headers,
            method='POST'
        )
        
        with urllib.request.urlopen(req, timeout=30) as response:
            result = json.loads(response.read().decode('utf-8'))
            if result.get('Documents'):
                return result['Documents'][0]
            return None
            
    except Exception as e:
        logging.error(f'Failed to get metadata: {str(e)}')
        return None

def download_document(url):
    """Download document content from URL"""
    try:
        with urllib.request.urlopen(url, timeout=30) as response:
            content = response.read()
            content_type = response.headers.get('Content-Type', 'application/octet-stream')
            
        return {
            "success": True,
            "content": content,
            "content_type": content_type,
            "size": len(content)
        }
    except Exception as e:
        logging.error(f'Document download failed: {str(e)}')
        return {"success": False, "error": str(e)}

def calculate_content_hash(content):
    """Calculate MD5 hash of content for change detection"""
    return hashlib.md5(content).hexdigest()

# Function App with function level authentication for security
app = func.FunctionApp(http_auth_level=func.AuthLevel.FUNCTION)

# Timer trigger function that runs every 4 hours
@app.timer_trigger(schedule="0 0 */4 * * *", arg_name="mytimer", run_on_startup=False,
              use_monitor=False) 
def scheduled_crawler(mytimer: func.TimerRequest) -> None:
    """Timer trigger function that crawls websites every 4 hours"""
    logging.info('Scheduled crawler function started - with REAL Azure Storage!')
    
    # Test crawling recent legislation
    try:
        test_url = "https://www.legislation.gov.uk/ukpga/2025/22"
        with urllib.request.urlopen(test_url, timeout=15) as response:
            content = response.read().decode('utf-8')
            result = find_documents_in_html(content, test_url)
            
        logging.info(f'Found {len(result["documents"])} documents on {test_url}')
        
        # Process first document if found
        if result["documents"]:
            doc = result["documents"][0]
            logging.info(f'Processing document: {doc["filename"]}')
            
            # Download document
            download_result = download_document(doc["url"])
            if download_result["success"]:
                # Calculate hash for change detection
                content_hash = calculate_content_hash(download_result["content"])
                
                # Upload to blob storage (REAL)
                upload_result = upload_to_blob_storage_real(
                    download_result["content"], 
                    doc["filename"]
                )
                
                logging.info(f'Document processing complete: {upload_result["message"]}')
                logging.info(f'Content hash: {content_hash}')
            
    except Exception as e:
        logging.error(f'Scheduled crawl failed: {str(e)}')

@app.route(route="manual_crawl", methods=["POST"])
def manual_crawl(req: func.HttpRequest) -> func.HttpResponse:
    """Manual trigger for crawling and downloading documents"""
    logging.info('Manual crawl function triggered - with REAL Azure Storage!')
    
    try:
        req_body = req.get_json()
        url = req_body.get('url') if req_body else None
        download_docs = req_body.get('download', False) if req_body else False
        use_real_storage = req_body.get('real_storage', True) if req_body else True
        
        if not url:
            url = "https://www.legislation.gov.uk/ukpga/2025/22"  # Default test URL
        
        # Basic URL validation
        if not url.startswith(('http://', 'https://')):
            return func.HttpResponse(
                json.dumps({"error": "Invalid URL - must start with http:// or https://"}),
                status_code=400,
                mimetype="application/json"
            )
        
        with urllib.request.urlopen(url, timeout=15) as response:
            content = response.read().decode('utf-8')
            result = find_documents_in_html(content, url)
        
        response_data = {
            "message": "Web crawler with REAL Azure Storage integration is working!",
            "url": url,
            "status_code": response.status,
            "documents_found": len(result["documents"]),
            "documents": result["documents"][:10],  # Limit to first 10
            "debug_info": {
                "total_links_found": result["total_links_found"],
                "sample_links": result["sample_links"]
            },
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        
        # Download and store documents if requested
        if download_docs and result["documents"]:
            downloads = []
            for doc in result["documents"][:2]:  # Limit to first 2 for testing real storage
                logging.info(f'Downloading {doc["filename"]}...')
                
                download_result = download_document(doc["url"])
                if download_result["success"]:
                    content_hash = calculate_content_hash(download_result["content"])
                    
                    if use_real_storage:
                        upload_result = upload_to_blob_storage_real(
                            download_result["content"], 
                            doc["filename"]
                        )
                    else:
                        # Fallback simulation
                        upload_result = {
                            "success": True,
                            "blob_url": f"https://stbtpuksprodcrawler01.blob.core.windows.net/documents/{doc['filename']}",
                            "size": len(download_result["content"]),
                            "message": "Simulated upload (real_storage=false)"
                        }
                    
                    downloads.append({
                        "filename": doc["filename"],
                        "size": download_result["size"],
                        "hash": content_hash,
                        "upload_success": upload_result["success"],
                        "blob_url": upload_result.get("blob_url", ""),
                        "message": upload_result.get("message", ""),
                        "real_storage": use_real_storage,
                        "status_code": upload_result.get("status_code"),
                        "error": upload_result.get("error")
                    })
                else:
                    downloads.append({
                        "filename": doc["filename"],
                        "error": download_result["error"]
                    })
            
            response_data["downloads"] = downloads
            
        return func.HttpResponse(
            json.dumps(response_data),
            status_code=200,
            mimetype="application/json"
        )
    except Exception as e:
        logging.error(f'Manual crawl error: {str(e)}')
        return func.HttpResponse(
            json.dumps({"error": str(e)}),
            status_code=500,
            mimetype="application/json"
        )

@app.route(route="crawler_status", methods=["GET"])
def crawler_status(req: func.HttpRequest) -> func.HttpResponse:
    """Get crawler system status and configuration"""
    logging.info('Crawler status endpoint called')
    
    status = {
        "system": "Azure Functions Web Crawler",
        "version": "2.0",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "azure_storage": {
            "account": STORAGE_ACCOUNT,
            "container": STORAGE_CONTAINER,
            "connected": True  # We know this works from previous tests
        },
        "cosmos_db": {
            "endpoint": COSMOS_ENDPOINT,
            "database": COSMOS_DATABASE,
            "container": COSMOS_CONTAINER,
            "connected": get_cosmos_access_token() is not None
        },
        "websites": {},
        "next_scheduled_run": "Every 4 hours (0 */4 * * *)"
    }
    
    # Add website configuration status
    for website_key, config in WEBSITE_CONFIGS.items():
        status["websites"][website_key] = {
            "name": config["name"],
            "enabled": config["enabled"],
            "priority": config["priority"],
            "base_url": config["base_url"],
            "crawl_paths_count": len(config["crawl_paths"])
        }
    
    return func.HttpResponse(
        json.dumps(status, indent=2),
        status_code=200,
        mimetype="application/json"
    )

@app.route(route="enable_website", methods=["POST"])
def enable_website(req: func.HttpRequest) -> func.HttpResponse:
    """Enable or disable specific websites for crawling"""
    logging.info('Enable website endpoint called')
    
    try:
        req_body = req.get_json()
        website_key = req_body.get('website_key')
        enabled = req_body.get('enabled', True)
        
        if website_key not in WEBSITE_CONFIGS:
            return func.HttpResponse(
                json.dumps({"error": f"Website '{website_key}' not found"}),
                status_code=404,
                mimetype="application/json"
            )
        
        WEBSITE_CONFIGS[website_key]['enabled'] = enabled
        
        return func.HttpResponse(
            json.dumps({
                "message": f"Website '{website_key}' {'enabled' if enabled else 'disabled'}",
                "website": WEBSITE_CONFIGS[website_key]['name'],
                "enabled": enabled
            }),
            status_code=200,
            mimetype="application/json"
        )
        
    except Exception as e:
        return func.HttpResponse(
            json.dumps({"error": str(e)}),
            status_code=400,
            mimetype="application/json"
        )

@app.route(route="search_site", methods=["GET"])
def search_site(req: func.HttpRequest) -> func.HttpResponse:
    """Search a specific site for documents with enhanced detection"""
    logging.info('Search site function triggered - with REAL Azure Storage!')
    
    url = req.params.get('url', 'https://www.legislation.gov.uk/')
    
    # Basic URL validation
    if not url.startswith(('http://', 'https://')):
        return func.HttpResponse(
            json.dumps({"error": "Invalid URL - must start with http:// or https://"}),
            status_code=400,
            mimetype="application/json"
        )
    
    try:
        with urllib.request.urlopen(url, timeout=15) as response:
            content = response.read().decode('utf-8')
            result = find_documents_in_html(content, url)
            
        return func.HttpResponse(
            json.dumps({
                "url": url,
                "status_code": response.status,
                "content_length": len(content),
                "documents_found": len(result["documents"]),
                "documents": result["documents"],
                "debug_info": {
                    "total_links_found": result["total_links_found"],
                    "sample_links": result["sample_links"]
                },
                "message": "Enhanced document search with REAL Azure Storage integration successful"
            }),
            status_code=200,
            mimetype="application/json"
        )
    except Exception as e:
        logging.error(f'Search site error: {str(e)}')
        return func.HttpResponse(
            json.dumps({"error": str(e)}),
            status_code=500,
            mimetype="application/json"
        )